Use MixingPlayer with this signature: public MixingPlayer(String name)
Im "jar"-Ordner befinden sich beide notwendigen JAR-Dateien (rtree2-0.9.3.jar und guava-mini-0.1.4.jar). Diese müssen mit der IDE als Library hinzugefügt werden (bei Intellij: Rechtsklick auf JAR-Datei > Add as library)
